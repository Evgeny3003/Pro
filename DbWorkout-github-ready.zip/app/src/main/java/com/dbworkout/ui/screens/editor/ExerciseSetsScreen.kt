package com.dbworkout.ui.screens.editor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dbworkout.R
import com.dbworkout.model.Difficulty
import com.dbworkout.model.label
import com.dbworkout.ui.components.EmptyState
import com.dbworkout.viewmodel.WorkoutEditorError
import com.dbworkout.viewmodel.WorkoutEditorViewModel
import com.dbworkout.viewmodel.isValid

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseSetsScreen(draftKey: Long, viewModel: WorkoutEditorViewModel, onBack: () -> Unit, onDone: () -> Unit, onOpenTimer: () -> Unit) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val exercise = state.exercises.firstOrNull { it.key == draftKey }
    val snackbar = remember { SnackbarHostState() }
    val error = if (state.error == WorkoutEditorError.INVALID_SETS) stringResource(R.string.error_invalid_sets) else null
    LaunchedEffect(draftKey, state.date) { viewModel.loadPreviousSets(draftKey) }
    LaunchedEffect(error) { if (error != null) { snackbar.showSnackbar(error); viewModel.clearError() } }
    Scaffold(
        modifier = Modifier.imePadding(), snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(stringResource(R.string.configure_exercise), fontWeight = FontWeight.SemiBold) }, navigationIcon = { IconButton(onClick=onBack){Icon(Icons.AutoMirrored.Rounded.ArrowBack,stringResource(R.string.back))} }, actions={IconButton(onClick={if(viewModel.exerciseHasValidSets(draftKey))onDone()}){Icon(Icons.Rounded.Check,stringResource(R.string.save))}}) }
    ){ padding ->
        if(exercise==null){ EmptyState(stringResource(R.string.no_exercises_in_workout),Modifier.padding(padding).fillMaxSize()) } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                item{Text(exercise.name,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold);Text(stringResource(R.string.set_input_tip),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
                if(state.previousSets.isNotEmpty()) item{
                    Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)){Column(Modifier.padding(14.dp)){Text(stringResource(R.string.previous_result),fontWeight=FontWeight.SemiBold);Text(state.previousSets.take(5).joinToString(" · "){set -> if(set.weightKg==null) "${set.reps} повт." else "${set.weightKg} кг × ${set.reps}"})}}
                }
                item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Text(stringResource(R.string.set_number),Modifier.width(42.dp),style=MaterialTheme.typography.labelMedium);Text(stringResource(R.string.repetitions),Modifier.weight(1f),style=MaterialTheme.typography.labelMedium);Text(stringResource(R.string.weight_kg),Modifier.weight(1f),style=MaterialTheme.typography.labelMedium);Spacer(Modifier.width(44.dp))}}
                itemsIndexed(exercise.sets,key={_,set->set.key}){index,set->
                    Column(Modifier.fillMaxWidth()){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                            Text((index+1).toString(),Modifier.width(42.dp),style=MaterialTheme.typography.titleMedium)
                            OutlinedTextField(value=set.reps,onValueChange={v->if(v.all(Char::isDigit))viewModel.updateSet(exercise.key,set.key,reps=v)},isError=set.reps.isNotBlank()&&(set.reps.toIntOrNull()?:0)<=0,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true,modifier=Modifier.weight(1f).testTag("reps_$index"))
                            OutlinedTextField(value=set.weightKg,onValueChange={v->if(v.all{it.isDigit()||it=='.'||it==','})viewModel.updateSet(exercise.key,set.key,weight=v)},isError=set.weightKg.isNotBlank()&&!set.isValid(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true,modifier=Modifier.weight(1f).testTag("weight_$index"))
                            IconButton(onClick={viewModel.removeSet(exercise.key,set.key)},enabled=exercise.sets.size>1){Icon(Icons.Rounded.DeleteOutline,stringResource(R.string.remove_set))}
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start=42.dp,top=6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Difficulty.entries.forEach{d->FilterChip(selected=set.difficulty==d,onClick={viewModel.selectDifficulty(exercise.key,set.key,d)},label={Text(d.label())})}
                        }
                    }
                }
                item{
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={viewModel.addSet(exercise.key)},Modifier.weight(1f).testTag("add_set")){Icon(Icons.Rounded.Add,null);Text(stringResource(R.string.add_set),Modifier.padding(start=8.dp))}
                        OutlinedButton(onClick=onOpenTimer,Modifier.weight(1f)){Text("Таймер 03:00") }
                    }
                }
            }
        }
    }
}
