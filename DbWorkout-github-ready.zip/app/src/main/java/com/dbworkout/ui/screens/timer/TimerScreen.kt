package com.dbworkout.ui.screens.timer

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dbworkout.R
import com.dbworkout.ui.components.DrawerScaffold
import com.dbworkout.ui.navigation.Routes
import com.dbworkout.viewmodel.TimerViewModel

@Composable
fun TimerScreen(viewModel:TimerViewModel,onNavigate:(String)->Unit,onCreateWorkout:()->Unit){
 val remaining by viewModel.remaining.collectAsStateWithLifecycle();val running by viewModel.running.collectAsStateWithLifecycle()
 val total=(remaining/1000).coerceAtLeast(0);val text="%02d:%02d".format(total/60,total%60)
 DrawerScaffold(title=stringResource(R.string.nav_timer),currentRoute=Routes.TIMER,onNavigate=onNavigate,onCreateWorkout=onCreateWorkout){padding->
  Column(Modifier.fillMaxSize().padding(padding).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
   Text(stringResource(R.string.rest_timer_title),style=MaterialTheme.typography.titleLarge)
   Spacer(Modifier.height(20.dp));Text(text,fontSize=64.sp,fontWeight=FontWeight.Bold)
   Spacer(Modifier.height(24.dp));Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){if(running)Button(onClick=viewModel::pause){Text(stringResource(R.string.pause))}else Button(onClick=viewModel::start){Text(stringResource(R.string.start))};OutlinedButton(onClick=viewModel::reset){Text(stringResource(R.string.reset))}}
   Spacer(Modifier.height(16.dp));Text(stringResource(R.string.timer_background_hint),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
  }
 }
}
