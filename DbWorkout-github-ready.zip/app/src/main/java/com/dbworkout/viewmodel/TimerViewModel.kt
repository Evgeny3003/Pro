package com.dbworkout.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dbworkout.timer.RestTimerService
import com.dbworkout.timer.TimerStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TimerViewModel(context:Context):ViewModel(){
 private val ctx=context.applicationContext; private val store=TimerStore(ctx)
 private val _remaining=MutableStateFlow(store.remaining()); val remaining:StateFlow<Long> = _remaining.asStateFlow()
 private val _running=MutableStateFlow(store.isRunning()); val running:StateFlow<Boolean> = _running.asStateFlow()
 init{viewModelScope.launch{while(isActive){_remaining.value=store.remaining();_running.value=store.isRunning();delay(250)}}}
 fun start()=command(RestTimerService.ACTION_START); fun pause()=command(RestTimerService.ACTION_PAUSE); fun reset()=command(RestTimerService.ACTION_RESET)
 private fun command(action:String){val i=android.content.Intent(ctx,RestTimerService::class.java).setAction(action);if(android.os.Build.VERSION.SDK_INT>=26)androidx.core.content.ContextCompat.startForegroundService(ctx,i) else ctx.startService(i)}
}
