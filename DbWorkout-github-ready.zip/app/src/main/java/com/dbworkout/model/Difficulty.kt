package com.dbworkout.model

enum class Difficulty {
    EASY,
    COULD_MORE,
    MEDIUM,
    HARDER,
    HARD,
}

fun Difficulty.label(): String = when (this) {
    Difficulty.EASY -> "Легко"
    Difficulty.COULD_MORE -> "Мог ещё"
    Difficulty.MEDIUM -> "Средне"
    Difficulty.HARDER -> "Тяжеловато"
    Difficulty.HARD -> "Тяжело"
}
