# Как собрать APK в Android Studio на Windows

1. Установить Android Studio.
2. Открыть папку `DbWorkout-main` через **Open**.
3. Дождаться Gradle Sync и установить предложенные Android SDK/Build Tools.
4. Подключить телефон с USB debugging или создать эмулятор.
5. Выбрать конфигурацию `app`.
6. Нажать **Run** для проверки приложения.
7. Для APK: открыть Terminal в Android Studio и выполнить:

```powershell
.\gradlew.bat :app:assembleDebug
```

APK будет здесь:

`app\build\outputs\apk\debug\app-debug.apk`

При первом запуске Android Studio может скачать Gradle, Android SDK и Maven-зависимости. Это нормально.
